pip install panel param openai langchain wikipedia python-dotenv requests




# run 
panel serve conversational_agent_app.py

# open in browser 
http://localhost:5006/conversational_agent_app
